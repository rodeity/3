AutoHotkey_LPortable\Data\lib standard\Readme.txt

This directory is moved to the same directory that AutoHotkey.exe is in and renamed to lib, which will cause it to be used as the Standard library: http://l.autohotkey.net/docs/Functions.htm#lib