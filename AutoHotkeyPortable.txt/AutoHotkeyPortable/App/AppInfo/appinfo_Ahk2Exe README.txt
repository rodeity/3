To create the Ahk2Exe launcher:

1) re-name appinfo.ini to appinfo.iniX  (any name will do, as long as it's changed)

2) re-name appinfo_Ahk2Exe.ini to appinfo.ini

3) re-name appicon.ico to appicon.icoX  (any name will do, as long as it's changed)

4) re-name appicon2.ico to appicon.ico

5) re-name Launcher/Custom.nsh to Custom.nshX  (any name will do, as long as it's changed)

6) Run PortableApps.com Launcher, it should generate a file name AutoHotkey2ExePortable.exe in the App's root directory

7) re-name files from step 1-5 back to their original names